import spotipy; import spotipy.util as util; import spotipy.oauth2

username='alostvagabond'
playlist_name='Moody - Happy'
scope = 'user-top-read playlist-modify-private playlist-modify-public user-modify-playback-state'
token = util.prompt_for_user_token(username,scope,client_id='8d90322721dc44d0a6d23ee72c458d91',client_secret='3523fb0d93c44e5ab51bd4c609ef057c',redirect_uri='http://localhost/')
sp = spotipy.Spotify(auth=token)

range = ['short_term']
genre = ['happy']

def get_top_artists():
    topArtists = sp.current_user_top_artists(time_range=range, limit=4)
    for item in (topArtists['items']):
        top_artists.append(item['id'])
    artistRecommendations = sp.recommendations(seed_artists = top_artists, seed_genres = genre, limit=50)
    for track in artistRecommendations['tracks']:
        track_ids.append(track['id'])

def get_top_tracks():
    topTracks = sp.current_user_top_tracks(time_range=range, limit=4)
    for item in (topTracks['items']):
        top_tracks.append(item['id'])
    trackRecommendations = sp.recommendations(seed_tracks = top_tracks, seed_genres = genre, limit=50)
    for track in trackRecommendations['tracks']:
        track_ids.append(track['id'])

def create_playlist():
    playlists = sp.user_playlist_create(username, playlist_name, public=True)
    playlist_id.append(playlists['id'])
    playlist_uri.append(playlists['uri'])
    playlist_id_string = ''.join(playlist_id)
    sp.user_playlist_add_tracks(username, playlist_id_string, track_ids)

def playback():
    playlist_uri_string = ''.join(playlist_uri)
    sp.start_playback(context_uri=playlist_uri_string)

top_artists = []; top_tracks = []; track_ids = []; playlist_id = []; playlist_uri = []

get_top_artists()
get_top_tracks()
create_playlist()
#playback()