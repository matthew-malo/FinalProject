import time
import sys
import os
import subprocess
import pprint
import sys
import json as simplejson
import spotipy
import spotipy.util as util

from spotipy.oauth2 import SpotifyClientCredentials
client_credentials_manager = SpotifyClientCredentials("8d90322721dc44d0a6d23ee72c458d91","3523fb0d93c44e5ab51bd4c609ef057c")
sp = spotipy.Spotify(client_credentials_manager=client_credentials_manager)
sp.trace=False

username='alostvagabond'
playlist_name='Moody - Happy'
scope = 'user-top-read playlist-modify-private playlist-modify-public user-modify-playback-state'
token = util.prompt_for_user_token(username,scope,client_id='8d90322721dc44d0a6d23ee72c458d91',client_secret='3523fb0d93c44e5ab51bd4c609ef057c',redirect_uri='http://localhost/')

#Get top artists

def get_top_artists():
    sp = spotipy.Spotify(auth=token)
    sp.trace = False
#    ranges = ['short_term', 'medium_term', 'long_term']
    ranges = ['short_term']
    for range in ranges:
        print ("range:", range)
#        global results
        results = sp.current_user_top_artists(time_range=range, limit=4)
        global item
        for i, item in enumerate(results['items']):
            top_artists.append(item['id'])
            print (i, item['name'], item['id'])
        print (results)
        print

def get_recommendations_from_artists():
    results = sp.recommendations(seed_artists = top_artists, seed_genres = ['happy'], limit=50)
    for track in results['tracks']:
        track_ids.append(track['id'])
        print (track['name'], '-', track['artists'][0]['name'], track['id'])

def get_top_tracks():
    sp = spotipy.Spotify(auth=token)
    sp.trace = False
#    ranges = ['short_term', 'medium_term', 'long_term']
    ranges = ['short_term']
    for range in ranges:
        print ("range:", range)
#        global results
        results = sp.current_user_top_tracks(time_range=range, limit=4)
        global item
        for i, item in enumerate(results['items']):
            top_tracks.append(item['id'])
            print (i, item['name'], item['id'])
        print (results)
        print

def get_recommendations_from_tracks():
    results = sp.recommendations(seed_tracks = top_tracks, seed_genres = ['happy'], limit=50)
    for track in results['tracks']:
        track_ids.append(track['id'])
        print (track['name'], '-', track['artists'][0]['name'], track['id'])

def create_playlist():
    sp = spotipy.Spotify(auth=token)
    sp.trace = False
    playlists = sp.user_playlist_create(username, playlist_name, public=True)
    playlist_id_list.append(playlists['id'])
    playlist_uri.append(playlists['uri'])
    print(playlist_id_list)
    pprint.pprint(playlists)

def add_to_playlist():
    sp = spotipy.Spotify(auth=token)
    sp.trace = False
    results = sp.user_playlist_add_tracks(username, playlist_id, track_ids)
    print(results)

def playback():
    sp = spotipy.Spotify(auth=token)
    sp.trace = False
    sp.start_playback(context_uri=playlist_uri)

top_artists = []
top_tracks = []
track_ids = []
playlist_id_list = []
playlist_uri = []

get_top_artists()
#print(top_artists)
get_top_tracks()
#print(top_tracks)
get_recommendations_from_artists()
get_recommendations_from_tracks()
#print(track_ids)
create_playlist()
playlist_id = ''.join(playlist_id_list)
playlist_uri = ''.join(playlist_uri)
#print(playlist_id)
add_to_playlist()
#playback()